f=open("file0.trace","r")
#opening the file and extracting data from it
data=[]
for i in f.readlines():
    i=i.split()
    data.append([int(i[0]),i[1]])
f.close()
t=0
nt=0
#initializing the taken and not taken counters
for i in data:
    if i[1]=='T':
        t+=1
    else:
        nt+=1
#printing the results
print("Mis-Prediction rate for always taken:",nt*100.0/len(data))
print("Mis-Prediction rate for always not-taken:",t*100.0/len(data))