f=open("file0.trace","r")
#opening the file and extracting data from it
data=[]
for i in f.readlines():
    i=i.split()
    data.append([int(i[0]),i[1]])
f.close()
#running the whole program for different types of branch history table
for n in range(2,21):
    d={}
    #initializing the counter for each type of branch history table
    for i in range(2**n):
        d[i]=0
    #counting the number of times correct prediction is taken from branch history table
    correctly_predicted=0
    for i in data:
        prediction_bits=i[0]%(2**n)
        #checking if the prediction is correct and updating the counter accordingly
        if i[1]=='T':
            if d[prediction_bits]<2:
                correctly_predicted+=1
            d[prediction_bits]-=1
            d[prediction_bits]=max(0,d[prediction_bits])
        elif i[1]=='N':
            if d[prediction_bits]>=2:
                correctly_predicted+=1
            d[prediction_bits]+=1
            d[prediction_bits]=min(3,d[prediction_bits])
    #printing the results
    print(f"Mis-Prediction rate for {n} bits:",(len(data)-correctly_predicted)*100.0/len(data))